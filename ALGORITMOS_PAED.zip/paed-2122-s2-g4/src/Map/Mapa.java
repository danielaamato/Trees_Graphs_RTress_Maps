package Map;

public class Mapa {

    private Empresa[] empreses;
    private int size;
    private long collissions;

    //private HashMap<Long,Long> mapa;

    /**
     * Constructor to set an initial capacity to the Hash-Table.
     *
     * @param initialCapacity initial capacity of the array.
     */
    public Mapa(int initialCapacity) {
        this.empreses = new Empresa[initialCapacity];
        //mapa = new HashMap<>(initialCapacity);
    }

    /**
     * Method to get the list of Empreses.
     *
     * @return list of empreses.
     */
    public Empresa[] getEmpreses() {
        return empreses;
    }

    /**
     * Method to insert new Empreses into the Hash-Table.
     *
     * @param newEmpresa new data to be inserted.
     */
    public void insertOA(Empresa newEmpresa) {
        long hash = hash(newEmpresa.getName());
        int index = (int) (hash % empreses.length);
        int i = 0;

        while (empreses[index] != null) {
            i++;
            long abs = Math.abs(hash + i * 53L + 7L * i * i);
            index = (int) (abs % empreses.length);
            collissions++;
        }

        empreses[index] = newEmpresa;
        size++;

        if (((float) size / empreses.length) > 0.75) {

            Empresa[] empresesToCopy = empreses;
            empreses = new Empresa[empreses.length * 2];
            size = 0;

            for (Empresa empresa : empresesToCopy) {
                if (empresa != null) {
                    insertOA(empresa);
                    collissions--;
                }
            }
        }
    }

    /**
     * Method to delete a Empresa in the Hash-Table.
     * Resizes table when 25% or less of the table is populated.
     *
     * @param key name of the Empresa to be deleted
     * @return true when delete is complete, false when it doesn't exist.
     */
    public boolean deleteOA(String key) {
        int index = findIndex(key);

        if (empreses[index] == null) {
            return false;
        }

        empreses[index] = null;
        size--;

        if (((float) size / empreses.length) <= 0.25) {

            Empresa[] empresesToCopy = empreses;
            empreses = new Empresa[empreses.length / 2];
            size = 0;

            for (Empresa empresa : empresesToCopy) {
                if (empresa != null) insertOA(empresa);
            }
        }
        return true;
    }

    /**
     * Mehtod to find the index that corresponts to a key
     * through a hash function while checking it doesn't already exist.
     *
     * @param key name of the Empresa to be found.
     * @return index of the key
     */
    private int findIndex(String key) {
        long hash = hash(key);
        int index = (int) (hash % empreses.length);
        int i = 0;

        while (empreses[index] != null && !(key.equals(empreses[index].getName()))) {
            i++;
            long abs = Math.abs(hash + i * 31L + 7L * i * i);
            index = (int) (abs % empreses.length);
        }
        return index;
    }

    /**
     * Method to find and return the corresponding Empresa to a key.
     *
     * @param key name of the Empresa being searched.
     * @return empresa that has been found.
     */
    public Empresa search(String key) {
        int index = findIndex(key);
        return empreses[index];
    }

    /**
     * Method that implements a hash function to return a hash.
     *
     * @param stringToHash string to be hashed.
     * @return hash.
     */
    private long hash(String stringToHash) {
        return char2Hash(stringToHash);
    }

    /**
     * Method that creates a hash from a String. It creates a unique number that represents the string.
     *
     * @param stringToHash string to be hashed.
     * @return hash.
     */
    private int char2Hash(String stringToHash) {
        final int p = 31, m = 1000000007;
        int hash_so_far = 0;
        final char[] s = stringToHash.toCharArray();
        long p_pow = 1;
        for (char c : s) {
            //149
            hash_so_far = (int) ((hash_so_far + (c - '0' + 1) * p_pow) % m);
            p_pow = (p_pow * p) % m;
        }
        return Math.abs(hash_so_far);
    }
}