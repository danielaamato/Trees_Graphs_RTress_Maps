package Map;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class MapsDAO {
    private final String path = "files/";


    /**
     * Method to read the file of the table.
     *
     * @param filename String of the filename that wants to read.
     * @return the hash-table complete
     * @throws IOException if occurs some error during the reading of the file.
     */
    public Mapa readFile(String filename) throws IOException {
        List<String> lines = Files.readAllLines(Path.of(path + filename));

        int numberOfEmpreses = Integer.parseInt(lines.get(0));

        Mapa mapa = new Mapa((int) (numberOfEmpreses * 1.5));

        for (int i = 0; i < numberOfEmpreses; i++) {
            String line = lines.get(i + 1);
            String[] split = line.split(";");

            Empresa empresa = new Empresa(
                    split[0],
                    split[1],
                    Integer.parseInt(split[2])
            );

            mapa.insertOA(empresa);
        }
        return mapa;
    }
}
