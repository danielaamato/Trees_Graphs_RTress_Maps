package Map;

import java.text.DecimalFormat;

public class Empresa {
    private final String dia;
    private final String name;
    private final int preu;

    /**
     * Constructor method of the Empresa with all the parameters.
     *
     * @param name name of the Empresa.
     * @param dia  day of the empresa to be announced.
     * @param preu price of the ad.
     */
    public Empresa(String name, String dia, int preu) {
        this.name = name;
        this.dia = dia;
        this.preu = preu;
    }

    /**
     * Getter for the name of the Empresa.
     *
     * @return name of the Empresa.
     */
    public String getName() {
        return name;
    }

    /**
     * Getter for the day of the empresa to be announced.
     *
     * @return day of the empresa.
     */
    public String getDia() {
        return dia;
    }

    /**
     * Custom tosString
     *
     * @return string composed of the name, day and price.
     */
    @Override
    public String toString() {
        DecimalFormat formato = new DecimalFormat("#,###.##");
        return "\tNom: " + name + '\n' +
                "\tDia: " + dia + "\n" +
                "\tPreu: " + formato.format(preu) + "€";
    }
}
