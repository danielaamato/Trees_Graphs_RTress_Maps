package Map.Options;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class HistogramFrame extends JPanel {
    private final int histogramHeight = 200;
    private final int histogramWidth = 50;
    private final int statisticsGap = 10;

    private final JPanel statisticsPanel;
    private final JPanel labelPanel;

    private final List<Statistics> statistics = new ArrayList<>();

    /**
     * crear el panel
     */
    public HistogramFrame() {
        setBorder(new EmptyBorder(10, 10, 10, 10));
        setLayout(new BorderLayout());

        statisticsPanel = new JPanel(new GridLayout(1, 0, statisticsGap, 0));
        Border inner = new EmptyBorder(10, 10, 0, 10);
        statisticsPanel.setBorder(inner);

        labelPanel = new JPanel(new GridLayout(1, 0, statisticsGap, 0));
        labelPanel.setBorder(new EmptyBorder(5, 10, 0, 10));

        add(statisticsPanel, BorderLayout.CENTER);
        add(labelPanel, BorderLayout.PAGE_END);
    }

    /**
     * Datos a mostrar
     *
     * @param monday    suma del dia
     * @param tuesday   suma del dia
     * @param wednesday suma del dia
     * @param thursday  suma del dia
     * @param friday    suma del dia
     * @param saturday  suma del dia
     * @param sunday    suma del dia
     */
    public static void createAndShowGUI(int monday, int tuesday, int wednesday, int thursday, int friday, int saturday, int sunday) {
        HistogramFrame panel = new HistogramFrame();
        panel.addHistogramColumn("Monday", monday, Color.RED);
        panel.addHistogramColumn("Tuesday", tuesday, Color.YELLOW);
        panel.addHistogramColumn("Wednesday", wednesday, Color.BLUE);
        panel.addHistogramColumn("Thursday", thursday, Color.ORANGE);
        panel.addHistogramColumn("Friday", friday, Color.MAGENTA);
        panel.addHistogramColumn("Saturday", saturday, Color.CYAN);
        panel.addHistogramColumn("Sunday", sunday, Color.PINK);
        panel.layoutHistogram();

        JFrame frame = new JFrame("Histogram Panel");
        frame.setSize(800, 800);
        frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        frame.add(panel);
        frame.setLocationByPlatform(true);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    /**
     * Datos a poner en la barra
     *
     * @param label Nombre a mostar
     * @param value El numero, por ejemplo suma de todos los dias del lunes
     * @param color El color a mostrar
     */
    public void addHistogramColumn(String label, int value, Color color) {
        Statistics bar = new Statistics(label, value, color);
        statistics.add(bar);
    }

    /**
     * Los layouts a mostrar dentro del panel.
     */
    public void layoutHistogram() {
        statisticsPanel.removeAll();
        labelPanel.removeAll();

        // Valor más alto de la estadística
        int maxValue = 0;
        for (Statistics stat : statistics) {
            maxValue = Math.max(maxValue, stat.value());
        }

        for (Statistics stat : statistics) {
            JLabel label = new JLabel(stat.value() + "");
            label.setHorizontalTextPosition(JLabel.CENTER);
            label.setHorizontalAlignment(JLabel.CENTER);
            label.setVerticalTextPosition(JLabel.TOP);
            label.setVerticalAlignment(JLabel.BOTTOM);

            int statisticHeight = (stat.value() * histogramHeight) / maxValue;
            Icon icon = new ColorIcon(stat.color(), histogramWidth, statisticHeight);

            label.setIcon(icon);
            statisticsPanel.add(label);

            JLabel statLabel = new JLabel(stat.day());
            statLabel.setHorizontalAlignment(JLabel.CENTER);
            labelPanel.add(statLabel);
        }
    }

    /**
     * Crear una clases Stat para poder gestionar el contendo de la barra.
     */
    private record Statistics(String day, int value, Color color) {
    }

    /**
     * Crear el objeto ColorIcon para poder controlar los el color y el tamaño de la barra.
     */
    private record ColorIcon(Color color, int width, int height) implements Icon {

        public int getIconWidth() {
            return width;
        }

        public int getIconHeight() {
            return height;
        }

        public void paintIcon(Component c, Graphics g, int x, int y) {
            g.setColor(color);
            g.fillRect(x, y, width, height);
            g.setColor(Color.GRAY);
            g.fillRect(x + width, y, 0, height);
        }
    }
}
