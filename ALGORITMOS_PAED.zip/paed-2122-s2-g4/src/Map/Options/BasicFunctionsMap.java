package Map.Options;

import Map.Empresa;
import Map.Mapa;

public class BasicFunctionsMap {

    private final Mapa mapa;

    /**
     * Constructor to get the Hash-Table.
     *
     * @param mapa hash-table.
     */
    public BasicFunctionsMap(Mapa mapa) {
        this.mapa = mapa;
    }

    /**
     * Method to introduce a new Empresa into the Hash-Table.
     *
     * @param newEmpresa new Empresa being added.
     */
    public void put(Empresa newEmpresa) {
        mapa.insertOA(newEmpresa);
        System.out.println("\nL'empresa s'ha afegit correctament al sistema gestor d'anuncis.");
    }

    /***
     * Method to delete an Empresa from the Hash-Table.
     * @param key name of the Empresa being deleted.
     */
    public void delete(String key) {
        if (mapa.deleteOA(key)) {
            System.out.println("\nL'empresa s'ha eliminat correctament del sistema gestor d'anuncis.");
        } else {
            System.out.println("\nNo se ha encontrado la empresa");
        }
    }

    /**
     * Method to search an Empresa in the Hash-Table.
     *
     * @param key name of the Empresa being searched.
     */
    public void search(String key) {
        Empresa empresa = mapa.search(key);
        if (empresa != null) {
            System.out.println("\n" + empresa);
        } else {
            System.out.println("\nNo se ha encontrado la empresa");
        }
    }

    /**
     * Method that traverses all the array in the map to get the data to create a histogram.
     *
     * @return array of 7 positions for every day of the week
     */
    public int[] histogram() {
        int monday = 0, tuesday = 0, wednesday = 0, thursday = 0, friday = 0, saturday = 0, sunday = 0;
        Empresa[] empresas = mapa.getEmpreses();
        for (Empresa empresa : empresas) {
            if (empresa != null) {
                switch (empresa.getDia().toLowerCase()) {
                    case "monday" -> monday++;
                    case "tuesday" -> tuesday++;
                    case "wednesday" -> wednesday++;
                    case "thursday" -> thursday++;
                    case "friday" -> friday++;
                    case "saturday" -> saturday++;
                    case "sunday" -> sunday++;
                }
            }
        }
        return new int[]{monday, tuesday, wednesday, thursday, friday, saturday, sunday};
    }
}
