package Map;

import java.util.Scanner;

import static Map.MenuOptionsMaps.*;

public class UIManagerMaps {
    private final Scanner scanner;

    /**
     * Constructor of the class where we initialize the scanner to get inputs.
     */
    public UIManagerMaps() {
        scanner = new Scanner(System.in);
    }

    /**
     * Method to show the options for the map menu.
     *
     * @return the options of the map menu.
     */
    public MenuOptionsMaps showMapsMenu() {
        do {
            System.out.println("""
                                   
                    \tA. Afegir empresa
                    \tB. Eliminar empresa
                    \tC. Consultar empresa
                    \tD. Histograma per dies
                      
                    \tE. Tornar enrere
                    """);
            System.out.print("Quina funcionalitat vols executar? ");

            try {
                char option = scanner.next().charAt(0);
                scanner.nextLine();

                switch (option) {
                    case 'A':
                        return AFEGIR;
                    case 'B':
                        return ELIMINAR;
                    case 'C':
                        return CONSULTAR;
                    case 'D':
                        return HISTOGRAMA;
                    case 'E':
                        return BACK;
                    default:
                        System.out.println("\nError, l'opció introduïda no és una opció vàlida.");
                }
            } catch (NumberFormatException e) {
                System.out.println("\nError, l'opció introduïda no és una opció vàlida.");
            }
        } while (true);
    }

    /**
     * Method to create a company asking for the necessary information
     * to save on the map.
     *
     * @return the new company with all the information.
     */
    public Empresa addCompany() {
        System.out.print("\nEntra el nom de l'empresa a afegir: ");
        String name = scanner.nextLine();

        System.out.print("Entra el dia de la setmana en el que està interessada: ");
        String day = scanner.nextLine();

        System.out.print("Entra el preu que pot pagar, en euros: ");
        int preu = scanner.nextInt();

        return new Empresa(name, day, preu);
    }

    /**
     * Method to get the name of the company that the
     * user wants to delete.
     *
     * @return the name of the company.
     */
    public String deleteCompany() {
        System.out.print("\nEntra el nom de l'empresa a eliminar: ");
        return scanner.nextLine();
    }

    /**
     * Método para buscar una Empresa.
     *
     * @return the company name to search.
     */
    public String searchCompany() {
        System.out.print("\nEntra el nom de l'empresa a consultar: ");
        return scanner.nextLine();
    }
}
