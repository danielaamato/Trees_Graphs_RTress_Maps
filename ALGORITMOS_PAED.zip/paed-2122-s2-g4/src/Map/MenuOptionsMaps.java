package Map;

public enum MenuOptionsMaps {
    // Add Empresa

    AFEGIR,

    // Delete Empresa

    ELIMINAR,

    //Check the value of a specific Empresa.

    CONSULTAR,

    // Visualize the Histogram.

    HISTOGRAMA,

    // To go back in the menu.

    BACK
}
