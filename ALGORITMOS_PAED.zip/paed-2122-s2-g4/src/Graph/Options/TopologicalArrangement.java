package Graph.Options;

import Graph.Graph;
import Graph.GraphDAO;
import Graph.User;

import java.io.IOException;
import java.util.LinkedList;

public class TopologicalArrangement {

    private final LinkedList<User> pila = new LinkedList<>();     // LinkedList with the visited Users
    private Graph graph;
    private boolean[] visited;

    /**
     * Método para ordenar
     *
     * @throws IOException exception is ignored.
     */
    public void topoSort() throws IOException {
        User user;
        graph = new Graph(new GraphDAO().readFile("dagS.paed"));
        visited = new boolean[graph.findListSize()];
        int visitedIsFalse = visitedIsFalse(visited);

        while (visitedIsFalse != -1) {
            user = graph.userList().get(visitedIsFalse);
            visita(user);
            visitedIsFalse = visitedIsFalse(visited);
        }
    }

    /**
     * Method used to go through all nodes in the graph and return them in a list.
     *
     * @param user user to start to search from.
     */
    public void visita(User user) {
        for (User u : graph.findAdjacent(graph.findUserIndex(user.getId()))) {
            if (!visited[graph.findUserIndex(u.getId())]) {
                visita(u);
            }
        }
        visited[graph.findUserIndex(user.getId())] = true;
        pila.add(user);
    }

    /**
     * Method used to find out if there are positions in the array that have not been visited.
     *
     * @param visited Boolean list for visited.
     * @return Returns the position that has not been visited. If all are visited, it returns -1.
     */
    private int visitedIsFalse(boolean[] visited) {
        for (int i = 0; i < visited.length; i++) {
            boolean b = visited[i];
            if (!b) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Method to print the result
     *
     * @throws IOException exception is ignored
     */
    public void view() throws IOException {
        topoSort();
        for (int i = 0; i < pila.size(); i++) {
            System.out.println(pila.get(i).getId() + " - " + pila.get(i).getName() + " (" + pila.get(i).getAlias() + ")");
            if (i == (pila.size() - 1)) {
                System.out.println();
            } else {
                System.out.println("↓");
            }
        }

    }
}
