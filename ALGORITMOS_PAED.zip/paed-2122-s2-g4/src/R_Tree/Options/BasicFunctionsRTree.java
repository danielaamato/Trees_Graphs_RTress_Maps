package R_Tree.Options;

import R_Tree.Cercle;
import R_Tree.Figura;
import R_Tree.RTree;
import R_Tree.Rectangle;

import java.util.ArrayList;
import java.util.List;

public class BasicFunctionsRTree {

    private final RTree rTree;
    private List<Cercle> cercles;

    /**
     * Constructor method of the basic functions of the R Tree class.
     *
     * @param rTree class with:
     *              - Insert function.
     *              - The root of the tree.
     */

    public BasicFunctionsRTree(RTree rTree) {
        this.rTree = rTree;
    }

    /**
     * Method to insert a new circle in the Rtree root.
     *
     * @param cercle circle that you want to insert in the RTree.
     */

    public void insertCercle(Cercle cercle) {
        rTree.setRoot(rTree.insert(rTree.getRoot(), cercle));
    }

    public void deleteCircle(Cercle cercle) {
        rTree.delete(rTree.getRoot(), cercle);
    }

    /**
     * Method to call the function to list the circles that are in a specific area
     * Print the number of circles found.
     * Print all the circles found.
     *
     * @param areaBuscar area where we want to search the circles.
     */

    public void circleArea(Rectangle areaBuscar) {
        this.cercles = new ArrayList<>();
        listCircleArea(rTree.getRoot(), areaBuscar);
        System.out.println();
        System.out.println("S'han trobat " + cercles.size() + " cercles en aquesta àrea:");
        System.out.println();

        for (Cercle cercle : cercles) {
            System.out.println(cercle);
        }
    }

    /**
     * Method to list all the circles which are inside a specific area.
     *
     * @param parent     the Rtree root with all the figures.
     * @param areaBuscar area where we want to get all the circles inside it.
     */

    public void listCircleArea(Figura parent, Rectangle areaBuscar) {
        if (parent instanceof Rectangle) {
            for (Figura node : ((Rectangle) parent).getNodes()) {
                if (node.isInside(areaBuscar)) {
                    listCircleArea(node, areaBuscar);
                }
            }
        } else {
            if (parent.isInside(areaBuscar)) {
                this.cercles.add((Cercle) parent);
            }
        }
    }

    /**
     * Method to call the function that list all the near circles given:
     *
     * @param circleToSearch where you want to search near.
     */

    public void listNearCircles(Cercle circleToSearch) {
        searchNearCircles(rTree.getRoot(), circleToSearch);
    }

    /**
     * Method to search all the circles near the circle given.
     * With a specific radius (5% of the window).
     * With similar colors.
     *
     * @param circleToSearch circle that you use as reference point.
     * @param parent         the Rtree root with all the figures.
     */

    public void searchNearCircles(Figura parent, Cercle circleToSearch) {
        // Search the circle

        if (parent instanceof Rectangle) {
            for (Figura node : ((Rectangle) parent).getNodes()) {
                if (node instanceof Cercle) {
                    searchNearCircles(node, circleToSearch);
                } else {
                    if (circleToSearch.isInside((Rectangle) parent)) {
                        searchNearCircles(node, circleToSearch);
                    }
                }
            }
        } else {
            if (((Cercle) parent).isSimilarColor(circleToSearch.getColor()) &&
                    ((Cercle) parent).isClose(rTree.getRoot().getX2(), rTree.getRoot().getY2(), circleToSearch)) {
                System.out.println(parent);
            }
        }
    }
}
