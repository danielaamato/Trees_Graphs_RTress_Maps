package R_Tree.Options;

import R_Tree.Cercle;
import R_Tree.Figura;
import R_Tree.RTree;
import R_Tree.Rectangle;

import javax.swing.*;
import java.awt.*;

public class RTreeView extends JPanel {
    private static final int PADDING = 4;
    private static final int OFFSET = 12;
    private static final int WINDOW_WIDTH = 800;
    private static final int WINDOW_HEIGHT = 800;
    private final double MAX_X;
    private final double MAX_Y;
    private final RTree rTree;

    /**
     * Constructor of the rTree class. It has:
     * - Window Width
     * - Window Height
     * - MAX_X (The maximum X of the Rectangle)
     * - MAX_Y (The maximum Y of the Rectangle)
     *
     * @param rTree with all the figures.
     */

    public RTreeView(RTree rTree) {
        MAX_X = rTree.getRoot().getX2();
        MAX_Y = rTree.getRoot().getY2();
        this.rTree = rTree;
    }

    /**
     * Method to initialize the visualization of the RTree
     * With all the points and all the rectangles drawn.
     *
     * @param rTree class with all the methods to insert points and rectangles.
     */

    public static void visualize(RTree rTree) {
        JFrame f = new JFrame();
        f.setTitle("RTree Visualization");

        f.getContentPane().add(new RTreeView(rTree), BorderLayout.CENTER);
        f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        f.setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        f.setLocationRelativeTo(null);
        f.setVisible(true);
    }

    /**
     * Method to paint the components.
     *
     * @param g Graphics component to paint.
     */

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        traverseRTree(rTree.getRoot(), g);
    }

    /**
     * Method to draw the Points and the Rectangles.
     *
     * @param figura Figure that could be a Circle or a Rectangle.
     * @param g      Graphics component to paint the figures.
     */

    private void traverseRTree(Figura figura, Graphics g) {
        if (figura instanceof Rectangle) {
            drawR(g, (Rectangle) figura);
            for (Figura node : ((Rectangle) figura).getNodes()) {
                traverseRTree(node, g);
            }
        } else {
            Cercle cercle = (Cercle) figura;
            drawP(g, cercle);
        }
    }

    /**
     * Method to draw a Point.
     * <p>
     * It has a fixed radius in order to have a better visualization of the circles.
     * It has the color set by the circle it received.
     *
     * @param g      Graphics component to paint.
     * @param cercle Circle that you want to draw.
     */

    private void drawP(Graphics g, Cercle cercle) {
        int radi = 3;
        g.setColor(cercle.getColor());
        double normalizedX = scaleX(cercle.getX());
        double normalizedY = scaleY(cercle.getY());
        g.fillOval((int) normalizedX - radi, (int) normalizedY - radi, radi * 2, radi * 2);
    }

    /**
     * Method to draw a Rectangle.
     * <p>
     * It has a random color.
     * It has the position given by the rectangle it received.
     *
     * @param g         Graphics component to paint.
     * @param rectangle that we want to draw.
     */

    private void drawR(Graphics g, Rectangle rectangle) {
        //Color c = new Color((int) (Math.random() * 255), (int) (Math.random() * 255), (int) (Math.random() * 255));
        g.setColor(Color.GRAY);
        //g.setColor(c);
        double normalizedHeight = scaleY(rectangle.getHeight());
        double normalizedWidth = scaleX(rectangle.getWidth());
        double normalizedX = scaleX(rectangle.getX1());
        double normalizedY = scaleY(rectangle.getY1());
        g.drawRect((int) normalizedX, (int) normalizedY, (int) normalizedWidth, (int) normalizedHeight);
    }

    /**
     * Method to scale the X of the points and the rectangles.
     *
     * @param x coordinate of a circle or rectangle.
     * @return the scaled width.
     */

    private double scaleX(double x) {
        return (getWidth() - OFFSET) * x / MAX_X + PADDING;
    }

    /**
     * Method to scale the Y of the points and the rectangles.
     *
     * @param y coordinate of a circle or rectangle.
     * @return the scaled width.
     */

    private double scaleY(double y) {
        return (getHeight() - OFFSET) * y / MAX_Y + PADDING;
    }
}