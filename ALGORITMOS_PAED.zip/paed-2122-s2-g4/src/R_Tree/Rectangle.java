package R_Tree;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Rectangle extends Figura {
    private final List<Figura> nodes;
    private double x1;
    private double y1;
    private double x2;
    private double y2;

    /**
     * Constructor methode of the Rectangle class.
     *
     * @param x1    X coordinate of the first point.
     * @param y1    Y coordinate of the first point.
     * @param x2    X coordinate of the second point.
     * @param y2    Y coordinate of the second point.
     * @param nodes list with all the points that are inside the rectangle.
     */

    public Rectangle(double x1, double y1, double x2, double y2, List<Figura> nodes) {
        this.nodes = nodes;
        double tmp;

        if (x1 > x2) {
            tmp = x1;
            x1 = x2;
            x2 = tmp;
        }
        if (y1 > y2) {
            tmp = y1;
            y1 = y2;
            y2 = tmp;
        }

        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
    }

    /**
     * Constructor methode to create a new Rectangle given
     * the coordinates of the center of the rectangle.
     *
     * @param center of the rectangle.
     */

    public Rectangle(double[] center) {
        this.nodes = new ArrayList<>();

        this.x1 = center[0];
        this.y1 = center[1];
        this.x2 = center[0];
        this.y2 = center[1];
    }

    /**
     * Calculate the perimeter of the Rectangle.
     *
     * @return the perimeter of the rectangle.
     */

    public double calcPerimeter() {
        return (x2 - x1) * 2 + (y2 - y1) * 2;
    }

    @Override
    public boolean isInside(Rectangle rectangle) {
        double delta_x = rectangle.getX2() - rectangle.getX1(), delta_y = rectangle.getY2() - rectangle.getY1();
        return ((x1 - rectangle.getX1()) >= 0 || (x2 - rectangle.getX2()) <= delta_x) || ((y1 - rectangle.getY1()) >= 0 || (y2 - rectangle.getY2()) <= delta_y);
    }


    /**
     * Method to set the newPerimeter of the rectangle.
     *
     * @param figura figure you want to set the new perimeter.
     * @return the value of the perimeter.
     */

    public double newPerimeter(Figura figura) {
        Rectangle temp = new Rectangle(x1, y1, x2, y2, null);

        temp.x1 = figura.calcMinX(x1);
        temp.y1 = figura.calcMinY(y1);
        temp.x2 = figura.calcMaxX(x2);
        temp.y2 = figura.calcMaxY(y2);

        return Math.abs(calcPerimeter() - temp.calcPerimeter());
    }

    /**
     * Method to update the area of the rectangle.
     */

    public void updateArea() {
        double minX = Double.MAX_VALUE;
        double minY = Double.MAX_VALUE;
        double maxX = Double.MIN_VALUE;
        double maxY = Double.MIN_VALUE;

        for (Figura node : nodes) {
            minX = node.calcMinX(minX);
            minY = node.calcMinY(minY);
            maxX = node.calcMaxX(maxX);
            maxY = node.calcMaxY(maxY);
        }

        x1 = minX;
        x2 = maxX;
        y1 = minY;
        y2 = maxY;
    }

    /**
     * Method to get the nodes of the rectangle.
     *
     * @return the list of nodes.
     */

    public List<Figura> getNodes() {
        return nodes;
    }

    /**
     * Method to add a new node in the rectangle.
     *
     * @param newNode figure you want to add to the rectangle nodes list.
     */

    public void addNode(Figura newNode) {
        newNode.setParent(this);
        nodes.add(newNode);

        updateArea();
    }

    public int[] calcFurthestFigures() {
        int[] indexes = new int[2];

        double maxDistance = Double.MIN_VALUE;

        for (Figura node : nodes) {
            double[] center = node.getCenter();

            for (Figura figura : nodes) {
                double[] point = figura.getCenter();
                double distance = distance(point[0], point[1], center[0], center[1]);
                if (distance > maxDistance) {
                    maxDistance = distance;
                    indexes[0] = getNodes().indexOf(node);
                    indexes[1] = getNodes().indexOf(figura);
                }
            }
        }
        return indexes;
    }

    /**
     * Method to calculate the distance between the points of the rectangle
     *
     * @param x1 X coordinate of the first point.
     * @param y1 Y coordinate of the first point.
     * @param x2 X coordinate of the second point.
     * @param y2 Y coordinate of the second point.
     * @return the distance between the two points.
     */

    private double distance(double x1, double y1, double x2, double y2) {
        double x = x1 - x2;
        double y = y1 - y2;

        return Math.sqrt(x * x + y * y);
    }

    @Override
    public double calcMaxX(Double x) {
        return Math.max(x2, x);
    }

    @Override
    public double calcMaxY(Double y) {
        return Math.max(y2, y);
    }

    @Override
    public double calcMinX(Double x) {
        return Math.min(x1, x);
    }

    @Override
    public double calcMinY(Double y) {
        return Math.min(y1, y);
    }

    @Override
    public double[] getCenter() {
        double[] coords = new double[2];

        coords[0] = (x1 + x2) / 2;
        coords[1] = (y1 + y2) / 2;

        return coords;
    }

    @Override
    public String toString() {
        return "R: " + nodes.size() +
                " nodes= \n" + nodes +
                "\n";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Rectangle rectangle = (Rectangle) o;
        return Double.compare(rectangle.x1, x1) == 0 && Double.compare(rectangle.y1, y1) == 0 && Double.compare(rectangle.x2, x2) == 0 && Double.compare(rectangle.y2, y2) == 0 && Objects.equals(nodes, rectangle.nodes);
    }

    @Override
    public int hashCode() {
        return Objects.hash(x1, y1, x2, y2, nodes);
    }

    public double getX1() {
        return x1;
    }

    public double getY1() {
        return y1;
    }

    public double getX2() {
        return x2;
    }

    public double getY2() {
        return y2;
    }

    public double getWidth() {
        return x2 - x1;
    }

    public double getHeight() {
        return y2 - y1;
    }

    public void deleteNode(Figura figura) {
        nodes.remove(figura);

        if (nodes.isEmpty()) {
            if (getParent() == null) {
                reset();
            } else {
                Rectangle grandParent = getParent();
                grandParent.deleteNode(this);
            }
        }
    }

    public void reset() {
        x1 = 0;
        y1 = 0;
        x2 = 0;
        y2 = 0;
    }
}