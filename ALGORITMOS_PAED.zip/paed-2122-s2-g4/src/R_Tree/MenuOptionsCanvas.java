package R_Tree;

public enum MenuOptionsCanvas {

    // Add Circle

    AFEGIR,

    // Delete Circle

    ELIMINAR,

    // Visualize the Canvas

    VISUALITZAR,

    // Find circles inside a specific area.

    CERCA_AREA,

    // Find circles that are close to a circle given.

    CERCA_ESPECIAL,

    // To go back in the menu.

    BACK
}
