package R_Tree;

import java.util.ArrayList;
import java.util.List;

public class RTree {

    private final int listSize = 3;
    private Rectangle root = new Rectangle(0, 0, 0, 0, new ArrayList<>());

    /**
     * Method to get the root.
     *
     * @return the root of the tree.
     */

    public Rectangle getRoot() {
        return root;
    }

    /**
     * Method to set the root.
     *
     * @param root with all the figures.
     */

    public void setRoot(Rectangle root) {
        this.root = root;
    }

    /**
     * Method to insert the new circles.
     * And where we have to avoid the overflow of both.
     *
     * @param parent  the RTree with all the figures.
     * @param newNode the circle that we want to insert.
     * @return the root with all the figures.
     */

    public Rectangle insert(Rectangle parent, Cercle newNode) {
        parent.updateArea();

        if (!parent.getNodes().isEmpty() && parent.getNodes().get(0) instanceof Rectangle) {
            int minIndex = getMinGrowthNode(parent, newNode);
            Figura figura = parent.getNodes().get(minIndex);
            insert((Rectangle) figura, newNode);
        } else {
            parent.addNode(newNode);
        }

        if (parent.getNodes().size() > listSize) {
            int[] indexes = parent.calcFurthestFigures();

            Figura furthestFigure1 = parent.getNodes().get(indexes[0]);
            Figura furthestFigure2 = parent.getNodes().get(indexes[1]);

            if (parent.getParent() == null) {
                List<Figura> nodes = new ArrayList<>(parent.getNodes());

                parent.getNodes().clear();

                Rectangle newBranch1 = new Rectangle(furthestFigure1.getCenter());
                newBranch1.addNode(furthestFigure1);
                parent.addNode(newBranch1);

                Rectangle newBranch2 = new Rectangle(furthestFigure2.getCenter());
                newBranch2.addNode(furthestFigure2);
                parent.addNode(newBranch2);

                nodes.remove(furthestFigure1);
                nodes.remove(furthestFigure2);

                for (Figura node : nodes) {
                    int minIndex = getMinGrowthNode(parent, node);
                    ((Rectangle) parent.getNodes().get(minIndex)).addNode(node);
                }
                parent.updateArea();
            } else {
                Rectangle grandParent = parent.getParent();

                Rectangle newRectangle = new Rectangle(furthestFigure1.getCenter());
                newRectangle.addNode(furthestFigure1);
                grandParent.addNode(newRectangle);

                List<Figura> nodes = new ArrayList<>(parent.getNodes());

                nodes.remove(furthestFigure1);
                nodes.remove(furthestFigure2);

                parent.getNodes().clear();

                parent.addNode(furthestFigure2);

                for (Figura node : nodes) {
                    int minIndex = getMinGrowthNode(grandParent, node);
                    ((Rectangle) grandParent.getNodes().get(minIndex)).addNode(node);
                }
                grandParent.updateArea();
            }
        }

        parent.updateArea();
        return parent;
    }


    /**
     * Method to delete a Circle in the tree.
     *
     * @param parent         parent of the subtree
     * @param cercleToDelete circle to be deleted
     * @return true when delete is complete, false when it doesn't exist.
     */
    public boolean delete(Rectangle parent, Cercle cercleToDelete) {
        List<Figura> nodes = parent.getNodes();
        if (nodes.get(0) instanceof Rectangle) {
            for (Figura node : nodes) {
                if (cercleToDelete.isInside((Rectangle) node)) {
                    boolean ended = delete((Rectangle) node, cercleToDelete);
                    if (ended) return true;
                }
            }
        } else {
            for (Figura node : nodes) {
                if (node.equals(cercleToDelete)) {
                    parent.deleteNode(node);
                    return true;
                }
            }
        }
        return false;
    }


    /**
     * Method to get the minimum growth of a node.
     *
     * @param parent  the root with all the nodes.
     * @param newNode the new node that we want to insert.
     * @return the minimum index of the rectangle with the minimum perimeter.
     */

    private int getMinGrowthNode(Rectangle parent, Figura newNode) {
        double minPerimeter = Double.MAX_VALUE;
        int minIndex = 0;
        for (int i = 0; i < parent.getNodes().size(); i++) {
            Rectangle rectangle = (Rectangle) parent.getNodes().get(i);
            double newPerimeter = rectangle.newPerimeter(newNode);

            if (newPerimeter <= minPerimeter) {
                minPerimeter = newPerimeter;
                minIndex = i;
            }
        }
        return minIndex;
    }
}