package R_Tree;

public abstract class Figura {

    // Rectangle Figure
    private Rectangle parent;

    /**
     * Method to get the parent of the rectangle.
     *
     * @return the rectangle parent.
     */

    public Rectangle getParent() {
        return parent;
    }

    /**
     * Method to set the parent of the rectangle.
     *
     * @param parent the rectangle you want to set as parent.
     */

    public void setParent(Rectangle parent) {
        this.parent = parent;
    }

    /**
     * Method to calculate the maximum X of the figure.
     *
     * @param x parameter of the figure.
     * @return the maximum X between the figure X and the X given.
     */

    public abstract double calcMaxX(Double x);

    /**
     * Method to calculate the maximum Y of the figure.
     *
     * @param y parameter of the figure.
     * @return the maximum Y between the figure Y and the Y given.
     */

    public abstract double calcMaxY(Double y);

    /**
     * Method to calculate the minimum X of the figure.
     *
     * @param x parameter of the figure.
     * @return the minimum X between the figure X and the X given.
     */

    public abstract double calcMinX(Double x);

    /**
     * Method to calculate the minimum Y of the figure.
     *
     * @param y parameter of the figure.
     * @return the minimum Y between the figure Y and the Y given.
     */

    public abstract double calcMinY(Double y);

    /**
     * Method to get the center of the figure.
     *
     * @return the coordinates of the center of the figure.
     */

    public abstract double[] getCenter();

    public abstract boolean isInside(Rectangle rectangle);

    public abstract boolean equals(Object o);
}
