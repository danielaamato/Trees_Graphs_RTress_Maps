package R_Tree;

import java.awt.*;
import java.util.Objects;

/**
 * Representa una fulla de la nostra estructura de l'arbre R.
 */
public class Cercle extends Figura {
    private final double x;
    private final double y;
    private final double radi;
    private final Color color;

    /**
     * Constructor method of the circle with all the parameters.
     *
     * @param x     coordinate of the circle.
     * @param y     coordinate of the circle.
     * @param radi  of the circle.
     * @param color of the circle.
     */

    public Cercle(double x, double y, double radi, String color) {
        this.x = x;
        this.y = y;
        this.radi = radi;
        this.color = Color.decode(color);
    }

    /**
     * Method to get the color of the circle.
     *
     * @return the color of the circle.
     */
    public Color getColor() {
        return color;
    }

    /**
     * Method to check if the color is similar to a color given.
     *
     * @param color of a circle.
     * @return True if the color is similar.
     */
    public boolean isSimilarColor(Color color) {
        return Math.abs((color.getRed()) - (this.color.getRed())) < 15 &&
                Math.abs((color.getGreen()) - (this.color.getGreen())) < 15 &&
                Math.abs((color.getBlue()) - (this.color.getBlue())) < 15;
    }

    /**
     * Get X position of the circle.
     *
     * @return the X position.
     */
    public double getX() {
        return x;
    }

    /**
     * Get Y position of the circle.
     *
     * @return the Y position.
     */
    public double getY() {
        return y;
    }

    /**
     * Method to calculate the maximum X of the circle.
     *
     * @param x position of the circle.
     * @return the Maximum between the X of the circle given and this.
     */
    @Override
    public double calcMaxX(Double x) {
        return Math.max(this.x, x);
    }

    /**
     * Method to calculate the maximum Y of the circle.
     *
     * @param y position of the circle.
     * @return the Maximum between the Y of the circle given and this.
     */
    @Override
    public double calcMaxY(Double y) {
        return Math.max(this.y, y);
    }

    /**
     * Method to calculate the minimum X of the circle.
     *
     * @param x position of the circle.
     * @return the minimum between the X of the circle given and this.
     */
    @Override
    public double calcMinX(Double x) {
        return Math.min(this.x, x);
    }

    /**
     * Method to calculate the maximum Y of the circle.
     *
     * @param y position of the circle.
     * @return the Maximum between the Y of the circle given and this.
     */
    @Override
    public double calcMinY(Double y) {
        return Math.min(this.y, y);
    }

    /**
     * Get the center of the circle.
     *
     * @return an Array with the coordinates of the center of the circle.
     */
    @Override
    public double[] getCenter() {
        return new double[]{x, y};
    }

    /**
     * ToString Method to print all the information as required.
     *
     * @return the string to print.
     */
    @Override
    public String toString() {
        String hex = "#" + Integer.toHexString(color.getRGB()).substring(2);
        return "\t" + hex + " (" + x + ", " + y + ") r=" + radi;
    }

    /**
     * Method that checks if the circle is inside a Rectangle.
     *
     * @param rectangle rectangle being checked.
     * @return true if the rectangle contains the circle.
     */
    @Override
    public boolean isInside(Rectangle rectangle) {
        double delta_x = rectangle.getX2() - rectangle.getX1(), delta_y = rectangle.getY2() - rectangle.getY1();
        return ((x - rectangle.getX1()) >= 0 && (x - rectangle.getX1()) <= delta_x) && ((y - rectangle.getY1()) >= 0 && (y - rectangle.getY1()) <= delta_y);
    }

    /**
     * Method to check if the circle is close to another circle.
     *
     * @param x2             the maximum X of the rectangle
     * @param y2             the maximum Y of the rectangle
     * @param circleToSearch the circle we want to search near.
     * @return True if the circle is close to the current circle.
     */

    public boolean isClose(double x2, double y2, Cercle circleToSearch) {
        double percentage_x = x2 * 5 / 100;
        double percentage_y = y2 * 5 / 100;

        return circleToSearch.isInside(new Rectangle(x - percentage_x, y - percentage_y, x + percentage_x, y + percentage_y, null));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Cercle cercle = (Cercle) o;
        return Double.compare(cercle.x, x) == 0 && Double.compare(cercle.y, y) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(x, y);
    }
}