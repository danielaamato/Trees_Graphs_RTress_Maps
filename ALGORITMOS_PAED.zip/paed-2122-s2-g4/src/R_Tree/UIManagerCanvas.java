package R_Tree;

import java.util.ArrayList;
import java.util.Scanner;

import static R_Tree.MenuOptionsCanvas.*;

public class UIManagerCanvas {
    private final Scanner scanner;

    /**
     * Constructor method to initialize the UIManager of the Canvas option.
     * Initialize the scanner to get and receive inputs.
     */

    public UIManagerCanvas() {
        scanner = new Scanner(System.in);
    }

    /**
     * Method to show the canvas menu options.
     * Ask the user the option he wants to do
     * and if it occurs some error show a message
     * error.
     *
     * @return the menu option selected.
     */

    public MenuOptionsCanvas showCanvasMenu() {
        do {
            System.out.println("""
                                   
                    \tA. Afegir cercle
                    \tB. Eliminar cercle
                    \tC. Visualitzar
                    \tD. Cerca per àrea
                    \tE. Cerca especial
                      
                    \tF. Tornar enrere
                    """);
            System.out.print("Quina funcionalitat vols executar? ");

            try {
                char option = scanner.next().charAt(0);
                scanner.nextLine();

                switch (option) {
                    case 'A':
                        return AFEGIR;
                    case 'B':
                        return ELIMINAR;
                    case 'C':
                        return VISUALITZAR;
                    case 'D':
                        return CERCA_AREA;
                    case 'E':
                        return CERCA_ESPECIAL;
                    case 'F':
                        return BACK;
                    default:
                        System.out.println("\nError, l'opció introduïda no és una opció vàlida.");
                }
            } catch (NumberFormatException e) {
                System.out.println("\nError, l'opció introduïda no és una opció vàlida.");
            }
        } while (true);
    }

    /**
     * Method to Ask the inputs of the circles.
     * The X coordinate of the circle.
     * The Y coordinate of the circle.
     * The Radius of the circle.
     * The Color of the circle.
     *
     * @return the Circle with all the parameters given.
     */

    public Cercle requestCircle() {
        System.out.print("\nEntra la coordenada X del centre del cercle a afegir: ");
        float x = Float.parseFloat(scanner.nextLine());

        System.out.print("Entra la coordenada Y del centre del cercle a afegir: ");
        float y = Float.parseFloat(scanner.nextLine());

        System.out.print("Entra el radi del cercle a afegir: ");
        float r = Float.parseFloat(scanner.nextLine());

        System.out.print("Entra el color del cercle a afegir: ");
        String color = scanner.nextLine();

        System.out.println("\nEl cercle s'ha afegit correctament al canvas.");

        return new Cercle(x, y, r, color);
    }

    /**
     * Method to ask the inputs to delete a circle.
     *
     * @return the circle to be deleted.
     */

    public Cercle deleteCircle() {
        System.out.print("\nEntra la coordenada X del centre del cercle a eliminar: ");
        double x = Double.parseDouble(scanner.nextLine());

        System.out.print("Entra la coordenada Y del centre del cercle a eliminar: ");
        double y = Double.parseDouble(scanner.nextLine());

        System.out.println("\nEl cercle s'ha eliminat correctament del canvas.");

        return new Cercle(x, y, 0, "#000000FF");
    }

    /**
     * Method to get inputs of a specific area.
     * Getting the first point (X and Y coordinates),
     * Getting the second point (X and Y coordinates),
     *
     * @return the Rectangle with all the parameters.
     */

    public Rectangle areaCircle() {
        System.out.print("\nEntra del primer punt del rectangle (X,Y): ");
        String prinerPunt = scanner.nextLine();

        System.out.print("Entra del segon punt del rectangle (X,Y): ");
        String segonPunt = scanner.nextLine();

        String[] xy1 = prinerPunt.split(",");
        String[] xy2 = segonPunt.split(",");

        double x1 = Double.parseDouble(xy1[0]);
        double y1 = Double.parseDouble(xy1[1]);
        double x2 = Double.parseDouble(xy2[0]);
        double y2 = Double.parseDouble(xy2[1]);

        return new Rectangle(x1, y1, x2, y2, new ArrayList<>());
    }

    /**
     * Method to search the near circles.
     * Gets the X coordinate of the circle.
     * Gets the Y coordinate of the circle.
     * Gets the Radius of the circle.
     * Gets the Color of the circle.
     *
     * @return The circle with all the parameters.
     */

    public Cercle searchCircle() {
        System.out.print("Entra la coordenada X del centre del cercle a cercar: ");
        float x = Float.parseFloat(scanner.nextLine());

        System.out.print("Entra la coordenada Y del centre del cercle a cercar: ");
        float y = Float.parseFloat(scanner.nextLine());

        System.out.print("Entra el radi del cercle a cercar: ");
        float r = Float.parseFloat(scanner.nextLine());

        System.out.print("Entra el color del cercle a cercar: ");
        String color = scanner.nextLine();

        System.out.println("\nEls cercles propers i semblants a aquest son: \n");

        return new Cercle(x, y, r, color);
    }
}
