Created by: Àlex Ferré, Tomás Uzcudún and Sami Amin
Logo: alex.fl, tomas.uzcudun, mohammedsami.amin
Subject: PAED - Project S2
Language used: java
IDE used: IntelliJ Idea
We use features introduced in the lastest versions such as Records.
To execute this project you need a JDK version 17 or higher.